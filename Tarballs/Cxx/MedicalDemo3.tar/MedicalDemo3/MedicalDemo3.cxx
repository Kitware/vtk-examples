// Derived from VTK/Examples/Cxx/Medical3.cxx
// This example reads a volume dataset, extracts two isosurfaces that
// represent the skin and bone, creates three orthogonal planes
// (sagittal, axial, coronal), and displays them.
//
#include <vtkActor.h>
#include <vtkAssembly.h>
#include <vtkCamera.h>
#include <vtkCameraOrientationRepresentation.h>
#include <vtkCameraOrientationWidget.h>
#include <vtkFlyingEdges3D.h>
#include <vtkImageActor.h>
#include <vtkImageMapToColors.h>
#include <vtkImageMapper3D.h>
#include <vtkImageResliceMapper.h>
#include <vtkInteractorStyleSwitch.h>
#include <vtkLookupTable.h>
#include <vtkMetaImageReader.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkOutlineFilter.h>
#include <vtkPlane.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkStringFormatter.h>
#include <vtkStripper.h>

#include <vtkTransform.h>
#include <vtk_cli11.h>
#include <vtk_fmt.h>
// clang-format off
#include VTK_FMT(fmt/format.h)
// clang-format on

#include <array>

namespace fs = std::filesystem;

namespace {

class Permute
{
  // clang-format off
  /*
   *    These transformations permute image and other geometric data to maintain
   *      proper orientation regardless of the acquisition order. After applying
   *      these transforms with vtkTransformFilter, a view up of 0, -1, 0 will
   *      result in the body part facing the viewer.
   *
   * NOTE: Some transformations have a -1 scale factor for one of the components.
   *    To ensure proper polygon orientation and normal direction,
   *      you must apply the vtkPolyDataNormals filter.
   *
   *   Naming (the nomenclature is medical):
   *     si - superior to inferior (top to bottom)
   *     is - inferior to superior (bottom to top)
   *     ap - anterior to posterior (front to back)
   *     pa - posterior to anterior (back to front)
   *     lr - left to right
   *     rl - right to left
   *
   */
  // clang-format on

public:
  /**
   * Generate the transforms corresponding to the slice order.
   */
  Permute()
  {
    GenerateTransforms();
  }

  virtual ~Permute() = default;

public:
  /**
   * Returns the vtkTransform corresponding to the permutation.
   *
   * @param permutation: The permutation.
   * @return The vtkTransform corresponding to the permutation.
   */
  vtkSmartPointer<vtkTransform> GetTransform(std::string const& permutation);

  /**
   * Print the homogenous matrix corresponding to the permutation.
   *
   * @param order: The permutation.
   */
  void PrintTransform(std::string const& permutation);

  /**
   * Print all the homogenous matrices corresponding to the permutations.
   *
   */
  void PrintAlltransforms();

private:
  /**
   * @brief Generate the transforms and collect them into a map.
   *
   */
  void GenerateTransforms();

private:
  std::map<std::string, vtkSmartPointer<vtkTransform>> transform;

  // Used to generate the the homogenous matrices corresponding to the
  //  permutations.
  std::array<double, 16> si_arr{1, 0,  0, 0, 0, 0, 1, 0,
                                0, -1, 0, 0, 0, 0, 0, 1};
  std::array<double, 16> is_arr{1, 0,  0, 0, 0, 0, -1, 0,
                                0, -1, 0, 0, 0, 0, 0,  1};
  std::array<double, 16> lr_arr{0, 0, -1, 0, 0, -1, 0, 0,
                                1, 0, 0,  0, 0, 0,  0, 1};
  std::array<double, 16> rl_arr{0, 0, 1, 0, 0, -1, 0, 0,
                                1, 0, 0, 0, 0, 0,  0, 1};
  std::array<double, 16> hf_arr{-1, 0, 0,  0, 0, 1, 0, 0,
                                0,  0, -1, 0, 0, 0, 0, 1};
  // Used to print out the homogenous matrices in the order
  //  entered into the transform map.
  std::vector<std::string> sort_order{};
};

class COWPlacement
{

public:
  COWPlacement()
  {
    MakeLabelColor();
  }

  virtual ~COWPlacement() = default;

public:
  /**
   * @brief Make a camera orientation widget for a given renderer.
   *    * position has these values
   *   0: LowerLeft,
   *   1: UpperLeft,
   *   2: LowerRight,
   *   3: UpperRight - the default
   *    * @param ren The renderer.
   * @param lcKey The key specifying the desired labels and colors for the axes.
   * @param position Where to position the camera orientation widget.
   * @return The camera orientation widget.
   */
  vtkNew<vtkCameraOrientationWidget>
  MakeCOW(vtkRenderer* ren, std::string lcKey = "XYZ", int const& position = 3);

private:
  typedef std::map<std::string, std::string> TAP;
  typedef std::map<std::string, TAP> TAPS;
  std::map<std::string, std::pair<TAP, TAP>> labelColor;

  /**
   * @brief Gather the defined axes labels and colors into a map.
   *    */
  void MakeLabelColor();
};

} // namespace

int main(int argc, char* argv[])
{
  CLI::App app{"A Composite image of three planes and translucent skin "
               "extracted from a CT dataset of the head."};

  // Define options
  std::string fileName;
  app.add_option("fileName", fileName,
                 "The path to the data file e.g. FullHead.mhd.")
      ->required()
      ->check(CLI::ExistingFile);

  bool flyingEdges = true;
  app.add_flag("-m{false},!-n", flyingEdges,
               "Use flying edges by default, marching cubes if set.");

  CLI11_PARSE(app, argc, argv);

  if (flyingEdges)
  {
#define USE_FLYING_EDGES
  }

  vtkNew<vtkNamedColors> colors;

  std::array<unsigned char, 4> skinColor{{240, 184, 160, 255}};
  colors->SetColor("SkinColor", skinColor.data());
  std::array<unsigned char, 4> bkg{{51, 77, 102, 255}};
  colors->SetColor("BkgColor", bkg.data());

  // Create the renderer, the render window, and the interactor. The
  // renderer draws into the render window, the interactor enables
  // mouse- and keyboard-based interaction with the data within the
  // render window.
  //
  vtkNew<vtkRenderer> ren;
  vtkNew<vtkRenderWindow> renWin;
  // Set a background color for the renderer and set the size of the
  // render window (expressed in pixels).
  ren->SetBackground(colors->GetColor3d("BkgColor").GetData());
  renWin->SetSize(640, 480);
  auto appFn = fs::path((app.get_name())).stem().string();
  renWin->SetWindowName(appFn.c_str());
  renWin->AddRenderer(ren);

  vtkNew<vtkRenderWindowInteractor> iren;
  iren->SetRenderWindow(renWin);
  auto is = vtkInteractorStyleSwitch::SafeDownCast(iren->GetInteractorStyle());
  if (is)
  {
    is->SetCurrentStyleToTrackballCamera();
  }

  // The following reader is used to read a series of 2D slices (images)
  // that compose the volume. The slice dimensions are set, and the
  // pixel spacing. The data Endianness must also be specified. The
  // reader uses the FilePrefix in combination with the slice number to
  // construct filenames using the format FilePrefix.%d. (In this case
  // the FilePrefix is the root name of the file: quarter.)
  vtkNew<vtkMetaImageReader> reader;
  reader->SetFileName(fileName.c_str());
  reader->Update();

  // An isosurface, or contour value of 500 is known to correspond to
  // the skin of the patient.
  // The triangle stripper is used to create triangle
  // strips from the isosurface; these render much faster on may
  // systems.
#ifdef USE_FLYING_EDGES
  vtkNew<vtkFlyingEdges3D> skinExtractor;
#else
  vtkNew<vtkMarchingCubes> skinExtractor;
#endif
  skinExtractor->SetInputConnection(reader->GetOutputPort());
  skinExtractor->SetValue(0, 500);
  skinExtractor->Update();

  vtkNew<vtkStripper> skinStripper;
  skinStripper->SetInputConnection(skinExtractor->GetOutputPort());
  skinStripper->Update();

  vtkNew<vtkPolyDataMapper> skinMapper;
  skinMapper->SetInputConnection(skinStripper->GetOutputPort());
  skinMapper->ScalarVisibilityOff();

  vtkNew<vtkActor> skin;
  skin->SetMapper(skinMapper);
  skin->GetProperty()->SetDiffuseColor(
      colors->GetColor3d("SkinColor").GetData());
  skin->GetProperty()->SetSpecular(0.3);
  skin->GetProperty()->SetSpecularPower(20);

  // An isosurface, or contour value of 1150 is known to correspond to
  // the bone of the patient.
  // The triangle stripper is used to create triangle
  // strips from the isosurface; these render much faster on may
  // systems.
#ifdef USE_FLYING_EDGES
  vtkNew<vtkFlyingEdges3D> boneExtractor;
#else
  vtkNew<vtkMarchingCubes> boneExtractor;
#endif
  boneExtractor->SetInputConnection(reader->GetOutputPort());
  boneExtractor->SetValue(0, 1150);

  vtkNew<vtkStripper> boneStripper;
  boneStripper->SetInputConnection(boneExtractor->GetOutputPort());

  vtkNew<vtkPolyDataMapper> boneMapper;
  boneMapper->SetInputConnection(boneStripper->GetOutputPort());
  boneMapper->ScalarVisibilityOff();

  vtkNew<vtkActor> bone;
  bone->SetMapper(boneMapper);
  bone->GetProperty()->SetDiffuseColor(colors->GetColor3d("Ivory").GetData());

  // An outline provides context around the data.
  //
  vtkNew<vtkOutlineFilter> outlineData;
  outlineData->SetInputConnection(reader->GetOutputPort());
  outlineData->Update();

  vtkNew<vtkPolyDataMapper> outlineMapper;
  outlineMapper->SetInputConnection(outlineData->GetOutputPort());

  vtkNew<vtkActor> outline;
  outline->SetMapper(outlineMapper);
  outline->GetProperty()->SetColor(colors->GetColor3d("Black").GetData());

  // This transform positions the actors correctly.
  // The face of the head will now face the observer.
  auto permute = Permute();
  auto lsa = permute.GetTransform("si");

  // Calculate the centroid of the head.
  auto bounds = skinMapper->GetBounds();
  std::array<double, 3> skinCentroid{0.0, 0.0, 0.0};
  for (auto i = 0; i < 6; i += 2)
  {
    auto x = bounds[i];
    auto y = bounds[i + 1];
    skinCentroid[(i + 1) / 2] = x + (y - x) / 2.0;
  }
  // Transform the centroid.
  // This is used to ensure that the orthogonal planes
  //  are positioned correctly for the head.
  std::array<double, 3> centroid{0.0, 0.0, 0.0};
  lsa->TransformVector(skinCentroid.data(), centroid.data());

  // Now we are creating three orthogonal planes passing through the
  // volume. Each plane uses a different texture map and therefore has
  // different coloration.

  // Start by creating a black/white lookup table.
  vtkNew<vtkLookupTable> bwLut;
  bwLut->SetTableRange(0, 2000);
  bwLut->SetSaturationRange(0, 0);
  bwLut->SetHueRange(0, 0);
  bwLut->SetValueRange(0, 1);
  bwLut->Build(); // effective built

  // Now create a lookup table that consists of the full hue circle
  // (from HSV).
  vtkNew<vtkLookupTable> hueLut;
  hueLut->SetTableRange(0, 2000);
  hueLut->SetHueRange(0, 1);
  hueLut->SetSaturationRange(1, 1);
  hueLut->SetValueRange(1, 1);
  hueLut->Build(); // effective built

  // Finally, create a lookup table with a single hue but having a range
  // in the saturation of the hue.
  vtkNew<vtkLookupTable> satLut;
  satLut->SetTableRange(0, 2000);
  satLut->SetHueRange(0.6, 0.6);
  satLut->SetSaturationRange(0, 1);
  satLut->SetValueRange(1, 1);
  satLut->Build(); // effective built

  // Use vtkImageMapToColors to map the scalar components of an input image
  // through a lookup table to produce an RGBA or RGB output imag
  // Then create a slice planes through a 3D image volume using
  // vtkImageSlice, combining it with a vtkImageResliceMapper and a vtkPlane.

  // Create the first (saggital) plane of the three planes.
  vtkNew<vtkImageMapToColors> sagittalColors;
  sagittalColors->SetInputConnection(reader->GetOutputPort());
  sagittalColors->SetLookupTable(bwLut);
  sagittalColors->Update();

  vtkNew<vtkPlane> sp;
  sp->SetOrigin(centroid.data());
  sp->SetNormal(1, 0, 0);

  vtkNew<vtkImageResliceMapper> sagittalMapper;
  sagittalMapper->SetInputConnection(sagittalColors->GetOutputPort());
  sagittalMapper->SetSlicePlane(sp); // Apply the custom slice plane

  vtkNew<vtkImageSlice> sagittalSlice;
  sagittalSlice->SetMapper(sagittalMapper);

  // Create the second (axial) plane of the three planes. We use the
  // same approach as before except that the extent differs.
  vtkNew<vtkImageMapToColors> axialColors;
  axialColors->SetInputConnection(reader->GetOutputPort());
  axialColors->SetLookupTable(hueLut);
  axialColors->Update();

  vtkNew<vtkPlane> ap;
  ap->SetOrigin(centroid.data());
  ap->SetNormal(0, 1, 0);

  vtkNew<vtkImageResliceMapper> axialMapper;
  axialMapper->SetInputConnection(axialColors->GetOutputPort());
  axialMapper->SetSlicePlane(ap); // Apply the custom slice plane

  vtkNew<vtkImageSlice> axialSlice;
  axialSlice->SetMapper(axialMapper);

  // Create the third (coronal) plane of the three planes. We use
  // the same approach as before except that the extent differs.
  vtkNew<vtkImageMapToColors> coronalColors;
  coronalColors->SetInputConnection(reader->GetOutputPort());
  coronalColors->SetLookupTable(satLut);
  coronalColors->Update();

  vtkNew<vtkPlane> cp;
  cp->SetOrigin(centroid.data());
  cp->SetNormal(0, 0, 1);

  vtkNew<vtkImageResliceMapper> coronalMapper;
  coronalMapper->SetInputConnection(coronalColors->GetOutputPort());
  coronalMapper->SetSlicePlane(cp); // Apply the custom slice plane

  vtkNew<vtkImageSlice> coronalSlice;
  coronalSlice->SetMapper(coronalMapper);

  // Turn off bone for this example.
  bone->VisibilityOff();

  // Set skin to semi-transparent.
  skin->GetProperty()->SetOpacity(0.5);

  // Combine the actors anto a single representation.
  vtkNew<vtkAssembly> assembly;
  assembly->AddPart(skin);
  assembly->AddPart(bone);
  assembly->AddPart(outline);
  assembly->AddPart(sagittalSlice);
  assembly->AddPart(axialSlice);
  assembly->AddPart(coronalSlice);
  // Apply the transform.
  assembly->SetUserTransform(lsa);
  // Add the assembly to the renderer.
  ren->AddActor(assembly);

  // It is convenient to create an initial view of the data. The
  // FocalPoint and Position form a vector direction. Later on
  // (ResetCamera() method) this vector is used to position the camera
  // to look at the data in this direction.
  vtkNew<vtkCamera> camera;
  camera->Azimuth(30.0);
  camera->Elevation(30.0);

  // An initial camera view is created. The Dolly() method moves
  // the camera towards the FocalPoint, thereby enlarging the image.
  ren->SetActiveCamera(camera);
  ren->ResetCamera();
  camera->Dolly(1.5);

  // Note that when camera movement occurs (as it does in the Dolly()
  // method), the clipping planes often need adjusting. Clipping planes
  // consist of two planes: near and far along the view direction. The
  // near plane clips out objects in front of the plane; the far plane
  // clips out objects behind the plane. This way only what is drawn
  // between the planes is actually rendered.
  ren->ResetCameraClippingRange();

  // Important: The interactor must be set prior to enabling the widget.
  auto cowp = COWPlacement();
  auto cow = cowp.MakeCOW(ren);
  // Enable the widget.
  cow->On();

  auto category = "LSA";
  auto cow1 = cowp.MakeCOW(ren, category, 1);
  // Enable the widget.
  cow1->On();

  // Interact with the data.
  iren->Initialize();
  iren->Start();

  return EXIT_SUCCESS;
}

namespace {

void Permute::GenerateTransforms()
{
  vtkNew<vtkMatrix4x4> si_mat;
  si_mat->SetData(this->si_arr.data());

  vtkNew<vtkMatrix4x4> is_mat;
  is_mat->SetData(this->is_arr.data());

  vtkNew<vtkMatrix4x4> lr_mat;
  lr_mat->SetData(this->lr_arr.data());

  vtkNew<vtkMatrix4x4> rl_mat;
  rl_mat->SetData(this->rl_arr.data());

  // The previous transforms assume radiological views of the slices
  //  (viewed from the feet).
  // Other modalities such as physical sectioning may view from the head.
  // The following transforms modify the original with a 180° rotation
  //  about the y-axis.

  vtkNew<vtkMatrix4x4> hf_mat;
  hf_mat->SetData(this->hf_arr.data());

  vtkNew<vtkTransform> si_trans;
  si_trans->SetMatrix(si_mat);
  this->transform["si"] = si_trans;
  this->sort_order.push_back("si");

  vtkNew<vtkTransform> is_trans;
  is_trans->SetMatrix(is_mat);
  this->transform["is"] = is_trans;
  this->sort_order.push_back("is");

  vtkNew<vtkTransform> ap_trans;
  ap_trans->Scale(1, -1, 1);
  this->transform["ap"] = ap_trans;
  this->sort_order.push_back("ap");

  vtkNew<vtkTransform> pa_trans;
  pa_trans->Scale(1, -1, -1);
  this->transform["pa"] = pa_trans;
  this->sort_order.push_back("pa");

  vtkNew<vtkTransform> lr_trans;
  lr_trans->SetMatrix(lr_mat);
  this->transform["lr"] = lr_trans;
  this->sort_order.push_back("lr");

  vtkNew<vtkTransform> rl_trans;
  lr_trans->SetMatrix(rl_mat);
  this->transform["rl"] = rl_trans;
  this->sort_order.push_back("rl");

  vtkNew<vtkTransform> hf_trans;
  hf_trans->SetMatrix(hf_mat);
  this->transform["hf"] = hf_trans;
  this->sort_order.push_back("hf");

  vtkNew<vtkTransform> hf_si_trans;
  hf_si_trans->SetMatrix(hf_mat);
  hf_si_trans->Concatenate(si_mat);
  this->transform["hfsi"] = hf_si_trans;
  this->sort_order.push_back("hfsi");

  vtkNew<vtkTransform> hf_is_trans;
  hf_is_trans->SetMatrix(hf_mat);
  hf_is_trans->Concatenate(is_mat);
  this->transform["hfis"] = hf_is_trans;
  this->sort_order.push_back("hfis");

  vtkNew<vtkTransform> hf_ap_trans;
  hf_ap_trans->SetMatrix(hf_mat);
  hf_ap_trans->Scale(1, -1, 1);
  this->transform["hfap"] = hf_ap_trans;
  this->sort_order.push_back("hfap");

  vtkNew<vtkTransform> hf_pa_trans;
  hf_pa_trans->SetMatrix(hf_mat);
  hf_pa_trans->Scale(1, -1, -1);
  this->transform["hfpa"] = hf_pa_trans;
  this->sort_order.push_back("hfpa");

  vtkNew<vtkTransform> hf_lr_trans;
  hf_lr_trans->SetMatrix(hf_mat);
  hf_lr_trans->Concatenate(lr_mat);
  this->transform["hflr"] = hf_lr_trans;
  this->sort_order.push_back("hflr");

  vtkNew<vtkTransform> hf_rl_trans;
  hf_rl_trans->SetMatrix(hf_mat);
  hf_rl_trans->Concatenate(rl_mat);
  this->transform["hfrl"] = hf_rl_trans;
  this->sort_order.push_back("hfrl");

  // Identity
  this->transform["I"] = vtkNew<vtkTransform>();
  this->sort_order.push_back("I");

  // Zero
  vtkNew<vtkTransform> z_trans;
  z_trans->Scale(0, 0, 0);
  this->transform["Z"] = z_trans;
  this->sort_order.push_back("Z");
}

void Permute::PrintTransform(std::string const& permutation)
{
  auto m = this->transform[permutation]->GetMatrix();
  vtk::println(permutation);
  for (int i = 0; i < 4; ++i)
  {
    for (int j = 0; j < 4; ++j)
    {
      if (j < 3)
      {
        vtk::print("{:>6.2g}", m->GetElement(i, j));
      }
      else
      {
        vtk::println("{:>6.2g}", m->GetElement(i, j));
      }
    }
  }
}

void Permute::PrintAlltransforms()
{
  for (auto const& k : this->sort_order)
  {
    PrintTransform(k);
  }
}

vtkSmartPointer<vtkTransform>
Permute::GetTransform(std::string const& permutation)
{
  return this->transform[permutation];
}

void COWPlacement::MakeLabelColor()
{
  vtkNew<vtkNamedColors> nc;

  // Define the axes labels and colors.
  // The three digit key refers to the positive X,Y,Z axes.
  // clang-format off
  TAPS labels {
    // Labels are: Anterior, Posterior, Dorsal, Ventral, Left, Right
    {"ADL",{{"+X", "A"}, {"+Y", "D"}, {"+Z", "L"}, {"-X", "P"}, {"-Y", "V"}, {"-Z", "R"}}},
    {"ALV",{{"+X", "A"}, {"+Y", "L"}, {"+Z", "V"}, {"-X", "P"}, {"-Y", "R"}, {"-Z", "D"}}},
    {"ADR",{{"+X", "A"}, {"+Y", "D"}, {"+Z", "R"}, {"-X", "P"}, {"-Y", "V"}, {"-Z", "L"}}},
    {"ARV",{{"+X", "A"}, {"+Y", "R"}, {"+Z", "V"}, {"-X", "P"}, {"-Y", "L"}, {"-Z", "D"}}},
    {"PDL",{{"+X", "P"}, {"+Y", "D"}, {"+Z", "L"}, {"-X", "A"}, {"-Y", "V"}, {"-Z", "R"}}},
    // Labels are: Left, Right, Superior, Inferior, Anterior, Posterior
    {"LAS",{{"+X", "L"}, {"+Y", "A"}, {"+Z", "S"}, {"-X", "R"}, {"-Y", "P"}, {"-Z", "I"}}},
    {"LPA",{{"+X", "L"}, {"+Y", "P"}, {"+Z", "A"}, {"-X", "R"}, {"-Y", "A"}, {"-Z", "S"}}},
    {"LPS",{{"+X", "L"}, {"+Y", "P"}, {"+Z", "S"}, {"-X", "R"}, {"-Y", "A"}, {"-Z", "I"}}},
    {"LSA",{{"+X", "L"}, {"+Y", "S"}, {"+Z", "A"}, {"-X", "R"}, {"-Y", "I"}, {"-Z", "A"}}},
    {"RAP",{{"+X", "R"}, {"+Y", "A"}, {"+Z", "P"}, {"-X", "L"}, {"-Y", "I"}, {"-Z", "S"}}},
    {"RAS",{{"+X", "R"}, {"+Y", "A"}, {"+Z", "S"}, {"-X", "L"}, {"-Y", "P"}, {"-Z", "I"}}},
    {"RPS",{{"+X", "R"}, {"+Y", "P"}, {"+Z", "S"}, {"-X", "L"}, {"-Y", "A"}, {"-Z", "I"}}},
    {"RSP",{{"+X", "R"}, {"+Y", "S"}, {"+Z", "P"}, {"-X", "L"}, {"-Y", "I"}, {"-Z", "A"}}},
    {"SAL",{{"+X", "S"}, {"+Y", "A"}, {"+Z", "L"}, {"-X", "I"}, {"-Y", "P"}, {"-Z", "R"}}},
    // Default labels.
    {"XYZ", {}},
    };
  TAP c1{
    {"+X", "IndianRed"},{"-X", "FireBrick"},
    {"+Y", "LimeGreen"},{"-Y", "DarkGreen"},
    {"+Z", "SkyBlue"}, {"-Z", "DeepSkyBlue"}
    };
  TAPS colors {
    {"ADL", c1},
    {"ALV", c1},
    {"ADR", c1},
    {"ARV", c1},
    {"PDL", c1},
    // Default colors.
    {"LAS", {}},
    {"LPS", {}},
    {"LPA", {}},
    {"LSA", {}},
    {"RAP", {}},
    {"RAS", {}},
    {"RPS", {}},
    {"RSP", {}},
    {"SAL", {}},
    // The default.
    {"XYZ", {}},
    };
  // clang-format on

  // The keys must be the same in the labels and colors variables.
  // Get the keys.
  std::set<std::string> labelKeys;
  for (auto&& label : labels)
  {
    labelKeys.insert(label.first);
  }
  std::set<std::string> colorKeys;
  for (auto&& label : colors)
  {
    colorKeys.insert(label.first);
  }
  std::vector<std::string> commonKeys;
  std::set_intersection(labelKeys.begin(), labelKeys.end(), colorKeys.begin(),
                        colorKeys.end(), std::back_inserter(commonKeys));
  for (auto&& k : commonKeys)
  {
    this->labelColor[k] = {labels[k], colors[k]};
  }
};

vtkNew<vtkCameraOrientationWidget>
COWPlacement::MakeCOW(vtkRenderer* ren, std::string lcKey, int const& position)
{
  std::set<std::string> keys;
  for (auto&& label : this->labelColor)
  {
    keys.insert(label.first);
  }
  auto it = keys.find(lcKey);
  if (it == keys.end())
  {
    std::string res =
        "Invalid key for axes labels and colors.\nValid keys are: ";
    for (const auto& [key, value] : this->labelColor)
    {
      res += fmt::format("{:s}, ", key);
    }
    if (res.length() >= 2)
    {
      auto pos = res.length() - 2;
      res.replace(pos, 2, "");
    }
    res += "\nUsing the key: XYZ";
    vtkfmt::println("{:}", res);
    lcKey = "XYZ";
  }
  auto lc = this->labelColor[lcKey];

  vtkNew<vtkCameraOrientationRepresentation> rep;

  switch (position)
  {
  case 0:
    rep->AnchorToLowerLeft();
    break;
  case 1:
    rep->AnchorToUpperLeft();
    break;
  case 2:
    rep->AnchorToLowerRight();
    break;
  default:
    rep->AnchorToUpperRight();
  }

  if (!lc.first.empty())
  {
    rep->SetXPlusLabelText(lc.first["+X"]);
    rep->SetXMinusLabelText(lc.first["-X"]);
    rep->SetYPlusLabelText(lc.first["+Y"]);
    rep->SetYMinusLabelText(lc.first["-Y"]);
    rep->SetZPlusLabelText(lc.first["+Z"]);
    rep->SetZMinusLabelText(lc.first["-Z"]);
  }

  if (!lc.second.empty())
  {
    vtkNew<vtkNamedColors> colors;

    rep->SetXAxisColor(colors->GetColor3d(lc.second["+X"]).GetData());
    rep->SetYAxisColor(colors->GetColor3d(lc.second["+Y"]).GetData());
    rep->SetZAxisColor(colors->GetColor3d(lc.second["+Z"]).GetData());
  }

  vtkNew<vtkCameraOrientationWidget> cow;
  cow->SetParentRenderer(ren);
  cow->SetRepresentation(rep);
  cow->Off();

  return cow;
}

} // namespace
