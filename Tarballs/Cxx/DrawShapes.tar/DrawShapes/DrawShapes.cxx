#include <vtkImageCanvasSource2D.h>
#include <vtkImageViewer2.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>

int main(int, char*[])
{
  vtkNew<vtkNamedColors> colors;

  vtkColor3ub color1;
  colors->GetColor("DimGray", color1);
  vtkColor3ub color2;
  colors->GetColor("HotPink", color2);

  // Create a blank, colored image.
  vtkNew<vtkImageCanvasSource2D> drawing;
  drawing->SetScalarTypeToUnsignedChar();
  drawing->SetNumberOfScalarComponents(3);
  drawing->SetExtent(0, 20, 0, 50, 0, 0);
  // Comment out or set color1 to "Black" if you want a black image.
  drawing->SetDrawColor(color1.GetRed(), color1.GetGreen(), color1.GetBlue());
  drawing->FillBox(0, 20, 0, 50);

  // Draw a red circle of radius 5 centered at (9,10).
  drawing->SetDrawColor(color2.GetRed(), color2.GetGreen(), color2.GetBlue());
  drawing->DrawCircle(9, 10, 5);
  drawing->Update();

  // View the result
  vtkNew<vtkRenderWindowInteractor> renderWindowInteractor;
  vtkNew<vtkImageViewer2> imageViewer;
  imageViewer->SetInputConnection(drawing->GetOutputPort());
  imageViewer->SetupInteractor(renderWindowInteractor);
  imageViewer->GetRenderer()->GradientBackgroundOn();
  imageViewer->GetRenderer()->SetBackground(
      colors->GetColor3d("SkyBlue").GetData());
  imageViewer->GetRenderer()->SetBackground2(
      colors->GetColor3d("MidnightBlue").GetData());
  imageViewer->GetRenderer()->ResetCamera();
  imageViewer->GetRenderWindow()->SetWindowName("DrawShapes");
  imageViewer->GetRenderWindow()->Render();
  renderWindowInteractor->Initialize();
  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}
