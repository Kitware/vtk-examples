#include <vtkImageActor.h>
#include <vtkImageMandelbrotSource.h>
#include <vtkImageMapper3D.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>

// #define USE_IMAGE_THRESHOLD
#ifdef USE_IMAGE_THRESHOLD
#include <vtkImageThreshold.h>
#else
#include <vtkImageBinaryThreshold.h>
#endif

int main(int, char*[])
{
  vtkNew<vtkNamedColors> colors;

  // Create an image.
  vtkNew<vtkImageMandelbrotSource> imageSource;
  imageSource->Update();

  unsigned char lower = 100;
  unsigned char upper = 200;

#ifdef USE_IMAGE_THRESHOLD
  vtkNew<vtkImageThreshold> imageThreshold;
  imageThreshold->SetInputConnection(imageSource->GetOutputPort());
  imageThreshold->ThresholdBetween(lower, upper);
  imageThreshold->ReplaceInOn();
  imageThreshold->ReplaceOutOn();
  imageThreshold->SetInValue(255);
  imageThreshold->SetOutValue(0);
#else
  vtkNew<vtkImageBinaryThreshold> imageThreshold;
  imageThreshold->SetInputConnection(imageSource->GetOutputPort());
  imageThreshold->SetThresholdFunction(
      vtkImageBinaryThreshold::THRESHOLD_BETWEEN);
  imageThreshold->SetLowerThreshold(lower);
  imageThreshold->SetUpperThreshold(upper);
  imageThreshold->ReplaceInOn();
  imageThreshold->ReplaceOutOn();
  imageThreshold->SetInValue(255);
  imageThreshold->SetOutValue(0);
#endif
  imageThreshold->Update();

  // Create actors.
  vtkNew<vtkImageActor> inputActor;
  inputActor->GetMapper()->SetInputConnection(imageSource->GetOutputPort());

  vtkNew<vtkImageActor> thresholdedActor;
  thresholdedActor->GetMapper()->SetInputConnection(
      imageThreshold->GetOutputPort());

  // There will be one render window.
  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->SetSize(600, 300);
  renderWindow->SetWindowName("ImageThreshold");

  // And one interactor.
  vtkNew<vtkRenderWindowInteractor> interactor;
  interactor->SetRenderWindow(renderWindow);

  // Define viewport ranges.
  // (xmin, ymin, xmax, ymax)
  double leftViewport[4] = {0.0, 0.0, 0.5, 1.0};
  double rightViewport[4] = {0.5, 0.0, 1.0, 1.0};

  // Setup both renderers.
  vtkNew<vtkRenderer> leftRenderer;
  renderWindow->AddRenderer(leftRenderer);
  leftRenderer->SetViewport(leftViewport);
  leftRenderer->SetBackground(.6, .5, .4);
  leftRenderer->SetBackground(colors->GetColor3d("Sienna").GetData());

  vtkNew<vtkRenderer> rightRenderer;
  renderWindow->AddRenderer(rightRenderer);
  rightRenderer->SetViewport(rightViewport);
  rightRenderer->SetBackground(.4, .5, .6);
  rightRenderer->SetBackground(colors->GetColor3d("RoyalBlue").GetData());

  leftRenderer->AddActor(inputActor);
  rightRenderer->AddActor(thresholdedActor);

  leftRenderer->ResetCamera();
  rightRenderer->ResetCamera();

  renderWindow->Render();
  interactor->Start();

  return EXIT_SUCCESS;
}
