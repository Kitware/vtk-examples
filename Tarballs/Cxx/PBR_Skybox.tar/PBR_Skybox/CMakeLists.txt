
cmake_minimum_required(VERSION 3.12 FATAL_ERROR)

project(PBR_Skybox)

find_package(VTK COMPONENTS 
  CommonColor
  CommonComputationalGeometry
  CommonCore
  CommonDataModel
  CommonTransforms
  FiltersCore
  FiltersGeneral
  FiltersModeling
  FiltersSources
  IOImage
  ImagingCore
  InteractionStyle
  InteractionWidgets
  RenderingAnnotation
  RenderingContextOpenGL2
  RenderingCore
  RenderingFreeType
  RenderingGL2PSOpenGL2
  RenderingOpenGL2
  cli11
  jsoncpp
)

if (NOT VTK_FOUND)
  message(FATAL_ERROR "PBR_Skybox: Unable to find the VTK build folder.")
endif()

# Prevent a "command line is too long" failure in Windows.
set(CMAKE_NINJA_FORCE_RESPONSE_FILE "ON" CACHE BOOL "Force Ninja to use response files.")
add_executable(PBR_Skybox MACOSX_BUNDLE PBR_Skybox.cxx )
  target_link_libraries(PBR_Skybox PRIVATE ${VTK_LIBRARIES}
)
# vtk_module_autoinit is needed
vtk_module_autoinit(
  TARGETS PBR_Skybox
  MODULES ${VTK_LIBRARIES}
)
