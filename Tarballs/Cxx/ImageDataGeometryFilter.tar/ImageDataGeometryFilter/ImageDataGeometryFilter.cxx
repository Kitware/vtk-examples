#include <vtkActor.h>
#include <vtkImageCanvasSource2D.h>
#include <vtkImageData.h>
#include <vtkImageDataGeometryFilter.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPolyDataMapper.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSphereSource.h>

int main(int, char*[])
{
  vtkNew<vtkNamedColors> colors;

  vtkColor3ub color1;
  colors->GetColor("SteelBlue", color1);
  vtkColor3ub color2;
  colors->GetColor("PaleGoldenrod", color2);

  // Create an image
  vtkNew<vtkImageCanvasSource2D> source1;
  source1->SetScalarTypeToUnsignedChar();
  source1->SetNumberOfScalarComponents(3);
  source1->SetExtent(0, 100, 0, 100, 0, 0);
  source1->SetDrawColor(color1.GetRed(), color1.GetGreen(), color1.GetBlue());
  source1->SetDrawColor(70, 130, 180);
  source1->FillBox(0, 100, 0, 100);
  source1->SetDrawColor(color2.GetRed(), color2.GetGreen(), color2.GetBlue());
  source1->SetDrawColor(238, 232, 170);
  source1->FillBox(10, 20, 10, 20);
  source1->FillBox(40, 50, 20, 30);
  source1->Update();

  // Convert the image to a polydata
  vtkNew<vtkImageDataGeometryFilter> imageDataGeometryFilter;
  imageDataGeometryFilter->SetInputConnection(source1->GetOutputPort());
  imageDataGeometryFilter->Update();

  // Create a mapper and actor
  vtkNew<vtkPolyDataMapper> mapper;
  mapper->SetInputConnection(imageDataGeometryFilter->GetOutputPort());

  vtkNew<vtkActor> actor;
  actor->SetMapper(mapper);

  // Visualization
  vtkNew<vtkRenderer> renderer;
  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->AddRenderer(renderer);
  vtkNew<vtkRenderWindowInteractor> renderWindowInteractor;
  renderWindowInteractor->SetRenderWindow(renderWindow);

  renderer->AddActor(actor);
  renderer->SetBackground(colors->GetColor3d("RosyBrown").GetData());

  renderWindow->SetWindowName("ImageDataGeometryFilter");
  renderWindow->Render();
  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}
