#include <vtkActor.h>
#include <vtkDataSetMapper.h>
#include <vtkImageCanvasSource2D.h>
#include <vtkImageContinuousErode3D.h>
#include <vtkImageData.h>
#include <vtkImageReader2.h>
#include <vtkImageReader2Factory.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>

#include <array>

int main(int argc, char* argv[])
{
  vtkNew<vtkNamedColors> colors;

  vtkNew<vtkImageData> image;

  if (argc < 2)
  {
    auto color1 = colors->GetColor3ub("Black");
    std::array<unsigned char, 3> drawColor1{color1.GetRed(), color1.GetGreen(),
                                            color1.GetBlue()};
    auto color2 = colors->GetColor3ub("Red");
    std::array<unsigned char, 3> drawColor2{color2.GetRed(), color2.GetGreen(),
                                            color2.GetBlue()};

    // Create an image
    vtkNew<vtkImageCanvasSource2D> source;
    source->SetScalarTypeToUnsignedChar();
    source->SetExtent(0, 200, 0, 200, 0, 0);
    source->SetDrawColor(drawColor1[0], drawColor1[1], drawColor1[1]);
    source->FillBox(0, 200, 0, 200);
    source->SetDrawColor(drawColor2[0], drawColor2[1], drawColor2[1]);
    source->FillBox(100, 150, 100, 150);
    source->Update();
    image->ShallowCopy(source->GetOutput());
  }
  else
  {
    vtkNew<vtkImageReader2Factory> readerFactory;
    vtkSmartPointer<vtkImageReader2> reader;
    reader.TakeReference(readerFactory->CreateImageReader2(argv[1]));
    reader->SetFileName(argv[1]);
    reader->Update();
    image->ShallowCopy(reader->GetOutput());
  }

  vtkNew<vtkDataSetMapper> originalMapper;
  originalMapper->SetInputData(image);

  vtkNew<vtkActor> originalActor;
  originalActor->SetMapper(originalMapper);

  vtkNew<vtkImageContinuousErode3D> erodeFilter;
  erodeFilter->SetInputData(image);
  erodeFilter->SetKernelSize(10, 10, 1);
  erodeFilter->Update();

  vtkNew<vtkDataSetMapper> erodedMapper;
  erodedMapper->SetInputConnection(erodeFilter->GetOutputPort());

  vtkNew<vtkActor> erodedActor;
  erodedActor->SetMapper(erodedMapper);

  // Visualize
  double leftViewport[4] = {0.0, 0.0, 0.5, 1.0};
  double rightViewport[4] = {0.5, 0.0, 1.0, 1.0};

  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->SetSize(600, 300);
  renderWindow->SetWindowName("ImageContinuousErode3D");

  vtkNew<vtkRenderWindowInteractor> interactor;
  interactor->SetRenderWindow(renderWindow);

  vtkNew<vtkRenderer> leftRenderer;
  renderWindow->AddRenderer(leftRenderer);
  leftRenderer->SetViewport(leftViewport);
  leftRenderer->SetBackground(colors->GetColor3d("Sienna").GetData());

  vtkNew<vtkRenderer> rightRenderer;
  renderWindow->AddRenderer(rightRenderer);
  rightRenderer->SetViewport(rightViewport);
  rightRenderer->SetBackground(colors->GetColor3d("RoyalBlue").GetData());

  leftRenderer->AddActor(originalActor);
  rightRenderer->AddActor(erodedActor);

  leftRenderer->ResetCamera();
  rightRenderer->SetActiveCamera(leftRenderer->GetActiveCamera());

  renderWindow->Render();
  interactor->Start();

  return EXIT_SUCCESS;
}
